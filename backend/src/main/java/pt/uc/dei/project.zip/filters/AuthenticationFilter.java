package pt.uc.dei.filters;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.*;
import jakarta.ws.rs.ext.Provider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import pt.uc.dei.annotations.AllowAnonymous;
import pt.uc.dei.dtos.ConfigurationDTO;
import pt.uc.dei.dtos.UserResponseDTO;
import pt.uc.dei.repositories.AppraisalRepository;
import pt.uc.dei.services.AuthenticationService;
import pt.uc.dei.services.ConfigurationService;
import pt.uc.dei.services.UserService;
import pt.uc.dei.utils.ApiResponse;
import pt.uc.dei.utils.JWTUtil;

import java.util.Date;

/**
 * JAX-RS authentication filter for validating JWT tokens and user authentication.
 * Skips authentication for endpoints annotated with @AllowAnonymous.
 */
@Provider
@Priority(Priorities.AUTHENTICATION)
public class AuthenticationFilter implements ContainerRequestFilter {

    private static final Logger LOGGER = LogManager.getLogger(AuthenticationFilter.class);

    @Inject
    private JWTUtil jwtUtil;

    @Inject
    private AuthenticationService authenticationService;

    @Inject
    private ConfigurationService configurationService;

    @Context
    private ResourceInfo resourceInfo;

    /**
     * Filters incoming requests to authenticate users based on JWT cookies.
     *
     * @param requestContext the request context
     */
    @Override
    public void filter(ContainerRequestContext requestContext) {
        boolean skipAuth = resourceInfo.getResourceMethod().isAnnotationPresent(AllowAnonymous.class)
                || resourceInfo.getResourceClass().isAnnotationPresent(AllowAnonymous.class);

        if (skipAuth) {
            return;
        }
        Cookie jwtCookie = requestContext.getCookies().get("jwt");

        if (jwtCookie == null || jwtCookie.getValue().isEmpty()) {
            abort(requestContext, Response.Status.UNAUTHORIZED, "Missing token");
            return;
        }

        try {
            Claims claims = JWTUtil.validateToken(jwtCookie.getValue());

            if (claims.getExpiration().before(new Date())) {
                abort(requestContext, Response.Status.UNAUTHORIZED, "Token expired");
                return;
            }

            Long id = Long.parseLong(claims.getSubject());
            UserResponseDTO user = authenticationService.getSelfInformation(id);
            if (user == null) {
                abort(requestContext, Response.Status.UNAUTHORIZED, "User not found");
                return;
            }

            // Store user and role info for downstream use (e.g., in endpoints or role filters)
            requestContext.setProperty("user", user);
            requestContext.setProperty("userIsAdmin", user.getUserIsAdmin());
            requestContext.setProperty("userIsManager", user.getUserIsManager());

            // ⏳ Check if the token is about to expire (e.g., less than 5 minutes left)
            long timeLeft = claims.getExpiration().getTime() - System.currentTimeMillis();
            if (timeLeft < 5 * 60 * 1000) {
                ConfigurationDTO configuration = configurationService.getLatestConfiguration();
                String newToken = jwtUtil.generateToken(user);
                NewCookie newCookie = new NewCookie("jwt", newToken, "/", null, null, (configuration.getLoginTime() * 60), true); // 1 hour
                requestContext.setProperty("newCookie", newCookie);
                requestContext.setProperty("newExpiration", JWTUtil.getExpiration(newToken));
                LOGGER.info("Storing new jwt cookie (expires in {} ms): {}", timeLeft, newCookie);
            }

        } catch (JwtException e) {
            abort(requestContext, Response.Status.FORBIDDEN, "Invalid token");
        }
    }

    private void abort(ContainerRequestContext context, Response.Status status, String message) {
        context.abortWith(Response.status(status)
                .entity(new ApiResponse(false, message, "authError", null))
                .type(MediaType.APPLICATION_JSON)
                .build());
    }
}